# Exercise 1 Basics
# Write a program to input two messages and output them to a user

def main():
    message1= input("Enter your first message ")
    message2= input("Enter your second message ")
    print("Your first message was {0} ".format(message1))
    print("Your second message was {0} ".format(message2))
    
