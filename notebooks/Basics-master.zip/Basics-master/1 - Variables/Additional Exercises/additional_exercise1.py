#16-01-2012
#additional exercise 1
#sample solution

print("Number Addition")
print("This program asks for three numbers and then outputs the total")
print()
num1 = int(input("Please enter a number: "))
num2 = int(input("Please enter a second number: "))
num3 = int(input("Please enter a third number: "))
print()
ans = num1 + num2 + num3
print("The total of {0} + {1} + {2} is {3}.".format(num1,num2,num3,ans))
