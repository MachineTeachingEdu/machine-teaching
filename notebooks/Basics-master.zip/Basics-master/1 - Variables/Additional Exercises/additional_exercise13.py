#16-01-2012
#additional exercise 13
#sample solution

print("Quote Formatter")
print("This program displays a given quote in different formats")
print()
quote = input("Please enter a quote to format: ")
print(quote)
print(quote.upper())
print(quote.lower())
print(quote.capitalize())
print(quote.title())


